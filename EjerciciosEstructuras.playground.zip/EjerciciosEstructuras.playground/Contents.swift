import UIKit

//Ej1. Algoritmo que pida un numero y diga si es positivo, negativo o 0.\
var num1 : Int = 5
if(num1>0){
    print("El numero introducido es positivo")
}else{
    if num1==0{
        print("El numero introducido es igual a 0")
    }else{
        print("El numero introducido es negativo")
    }
}

//Ej2. Escribe un programa que lea un numero e indique si es par o impar.\
var num2 : Int = 3
print(num2%2==0 ? "El número introducido es par" : "El número introducido es impar" )

//Ej3. Escribe un programa que dado un nombre de usuario y una contrasena \
//y si se ha introducido "pepe" y "asdasd" se indica "Has entrado al sistema", \
var nombre : String = "pepe"
var contrasena : String = "asdasd"

if(nombre == "pepe" && contrasena == "asdasd"){
    print("Has entrado al sistema")
}else{
    print("Usuario o contrasena incorrecto")
}

//Ej4. Programa que dada una cadena por teclado y compruebe si la primera letra es un "/"\
//y la segunda un "*", en caso afirmativo se escribira la palabra entera, en caso contrario\
//escribir "no es correcta".\
var frase : String = "/*asdasd"
if(frase.starts(with: "/*")){
    print(frase)
}else{
    print("La frase debe empezar con /*")
}

//Ej5. Algoritmo que dado tres numeros y los muestre ordenados (de mayor a menor);\
var numeros : [Int] = [3,1,5]
print(numeros.sorted())

//Ej6. //Algoritmo que pida los puntos centrales x1,y1,x2,y2 y los radios r1,r2 de dos \
//circunferencias y las clasifique en uno de estos estados:\
//exteriores\
//tangentes exteriores\
//secantes\
//tangentes interiores\
//interiores\
//conc\'e9ntricas\
//Repetitivas\


//Ej7. //Crea una aplicacion que pida un numero y calcule su factorial (El factorial de \
//un numero es el producto de todos los enteros entre 1 y el propio numero y se \
//representa por el n\'famero seguido de un signo de exclamacion. \
var num3 : Int = 4
var factorial : Int = 1
for i in 1...num3{
    factorial = factorial*i
}

print("El factorial de", num3, "es", factorial)


//Ej8. //Algoritmo que cree un array con 10 numeros. Debe imprimir la suma\
// y la media de todos los numeros introducidos.\
var suma : Double = 0.00
var numm=0.00;
var media : Double = 0.00;
var num4 : Int = 6v.setNombre("League of Legends");
var num5 : Int = 3
var num6 : Int = 2
var num7 : Int = 7
var num8 : Int = 8
var num9 : Int = 6
var num10 : Int = 5
var numeross : [Int] = [num1,num2,num3,num4,num5,num6,num7,num8,num9,num10]
while (!numeross.isEmpty) { // se pueden quitar los parentesis
    numm = Double(numeross.popLast()!)
    suma = suma+numm
}
media = suma / 10.00
print("La suma de todos los numeros es:", suma)
print("La media de todos los numeros es:", media)

//Ej9. //Algoritmo que cree un array con 10 numeros. El programa debe informar de cuantos numeros \
//introducidos son mayores que 0, menores que 0 e iguales a 0.\
var arrayEj9 : [Int] = [num1,num2,num3,num4,num5,num6,num7,num8,num9,num10]
var numpos : Int = 0
var numneg : Int = 0
var numcero : Int = 0
var numAct : Int = 0

while (!arrayEj9.isEmpty) { // se pueden quitar los parentesis
    numAct = arrayEj9.popLast()!
    if(numAct>0){
        numpos+=1
    }else{
        if numAct==0{
            numcero+=1
        }else{
            numneg+=1
        }
    }
}

print("Hay", numpos, "números positivos en el Array")
print("Hay", numneg, "números negativos en el Array")
print("Hay", numcero, "números cero en el Array")


//Ej 10 //Escribir un programa que imprima todos los numeros pares entre dos numeros\
var numini : Int = 4
var numfin : Int = 10

if(numini%2 != 0){
    numini+=1
}

for i in stride(from: numini, through: numfin, by: 2){
    print(i)
}


//Ej 11 ////Una empresa tiene el registro de las horas que trabaja diariamente un empleado \
//durante la semana (seis dias), asi como el sueldo que recibira por las horas trabajadas.\
//Las horas estan en un array y el precio hora esta en 30\'80}
