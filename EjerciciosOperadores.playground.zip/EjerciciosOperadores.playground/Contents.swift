import UIKit

//Ej1. Calcular el perimetro y area de un rectangulo dada su base y su altura.

var base = 4
var altura = 2

var perimetro = ((base*2) + (altura*2))
var area  = base*altura

print("El area del rectangulo es: \(area) ")
print("El perimetro del rectangulo es: \(perimetro) ")

//Ej2. Dados los catetos de un triangulo rectangulo, calcular su hipotenusa. funcion sqrt()
        //Nota: en online no funciona\ hay que "import UIKit"

import UIKit
var cat1 : Double = 4
var cat2 : Double = 2
var hipote : Double = sqrt((pow(cat1,2)) + (pow(cat2,2)))

print("La hipotenusa del triangulo es: \(hipote) ")

//Ej3. Dados dos numeros, mostrar la suma, resta, division y multiplicacion de ambos.\
var num1 = 6
var num2 = 3

var sum = num1+num2
var resta = num1-num2
var mult = num1*num2
var div = num1/num2

print("La suma es \(sum)")
print("La resta es \(resta)")
print("La multiplicacion es \(mult)")
print("La division es \(div)")

//Ej4. Escribir un programa que convierta un valor dado en grados Fahrenheit a grados Celsius.\
var faren = 59;
var grados = (faren - 32) * 5/9
print("\(faren) grados farenheit son \(grados) grados celsius")

//Ej5. Calcular la media de tres numeros pedidos por teclado

var num4 = 5.0
var num5 = 6.0
var num6 = 8.0

var media : Double = (num4+num5+num6)/3

print("La media es: \(media)")

//Ej6. Un vendedor recibe un sueldo base mas un 10% extra por comision de sus ventas, \
//    el vendedor desea saber cuanto dinero obtendr\'e1 por concepto de comisiones por \
//    las tres ventas que realiza en el mes y el total que recibir\'e1 en el mes tomando \
//    en cuenta su sueldo base y comisiones.\
var sbase = 1200
var venta1 = 200.0
var venta2 = 150.0
var venta3 = 100.0

var comision : Double = venta1/10 + venta2/10 + venta3/10

print("El vendedor cobrará \(sbase)€ de salario base mas \(comision)€ de comision")

//Ej7. Un alumno desea saber cual ser\'e1 su calificaci\'f3n final en la materia de IOS\
//    Dicha calificaci\'f3n se compone de los siguientes porcentajes:\
//    * 55% del promedio de sus tres calificaciones parciales.\
//    * 30% de la calificaci\'f3n del examen final.\
//    * 15% de la calificaci\'f3n de un trabajo final.\
var parc1 = 7.0
var parc2 = 8.0
var parc3 = 7.0
var exfinal = 9.0
var trabajo = 10.0

var mediaparc : Double = (parc1+parc2+parc3) / 3
var notaf : Double = mediaparc*0.55 + exfinal*0.30 + trabajo*0.15

print("La nota final de ios es \(notaf)")

//Ej8. Escribir un algoritmo para calcular la nota final de un estudiante, considerando que: \
//    por cada respuesta correcta 5 puntos, por una incorrecta -1 y por respuestas en \
//    blanco 0. Imprime el resultado obtenido por el estudiante.\
var corr = 6
var incorr = 2
var blanc = 2

var resultado = corr*5 - incorr
print("El resultado obtenido por el estudiante es \(resultado) puntos")

//Ej9. Calcula el sueldo de un trabajador, cuyo valor es su sueldo base m\'e1s un numero de horas\
//extra trabajadas, pero teniendo en cuenta que el dicho numero de horas puede ser nulo
var subase = 2000
var hextra : Int? = nil
var aux = 0
var horaextra = 19

var salario = subase + (hextra ?? aux) * horaextra

print("El trabajador ha hecho ",hextra ?? aux," horas extra y el salario se queda en: ",salario,"€")
