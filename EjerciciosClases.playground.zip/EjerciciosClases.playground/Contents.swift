import UIKit

/*
Implementar las siguientes clases o estructuras y sus relaciones (dise\'f1o del modelo):
Queremos formar un ordenador, el ordenador tendr\'e1 los siguientes propiedades:
    1) precio
    2) nombre del equipo
     3) Varios modulos de memoria ram, la ram tendr\'e1 las siguientes propiedades
            a) capacidad de almacenamiento
            b) fabricante
            c) si tiene RGB
    4) Tendremos un procesador, el procesador tendr\'e1 las siguientes propiedades
            a) velocidad del procesador
            b) numero de cores
            c) numero de hilos
            d) fabricante
    5) podremos tener varios unidades de almacenamiento, tendr\'e1n las siguientes propiedades
            a) capacidad de almacenamiento
            b) fabricante
            c) tipo de unidad (HD, SSD, Nvme)
    6) Tendr\'e1 una tarjeta grafica, con las siguientes propiedades
            a) ram
            b) consumo
            c) Cuda cores
            d) velocidad

Tareas:
1) implementar el sistema de clases o de estructuras (o mezcla)\
2) Instanciar un ordenador completo con todos sus objetos con informaci\'f3n.
*/

class Ram{
    var almacenamiento  = 0
    var fabricante = ""
    var rgb  = false
}
class Procesador{
    var velocidad  = ""
    var cores  = 0
    var hilos  = 0
    var fabricante = ""
}
class Almacenamiento{
    var almacenamiento  = 0
    var fabricante  = ""
    var tipo  = ""
}
class Grafica{
    var ram : String = ""
    var consumo = ""
    var cores  = 0
    var velocidad = ""
}

class Ordenador{
    var precio = 0
    var nombre = ""
    var ram = [Ram]()
    var procesador = Procesador()
    var almacenamiento = [Almacenamiento]()
    var grafica = Grafica()
    
    
}

var ram1 = Ram()
ram1.almacenamiento = 4
ram1.fabricante = "GSkill"
ram1.rgb = false

var ram2 = Ram()
ram2.almacenamiento = 4
ram1.fabricante = "GSkill"
ram1.rgb = false


var almacenamiento1 = Almacenamiento()
almacenamiento1.almacenamiento = 120
almacenamiento1.fabricante = "Kingston"
almacenamiento1.tipo="SSD"
var almacenamiento2 = Almacenamiento()
almacenamiento2.almacenamiento = 1000
almacenamiento2.fabricante = "WD"
almacenamiento2.tipo="Mecanico"

var procesador = Procesador()
procesador.cores = 3
procesador.fabricante = "intel"
procesador.hilos = 4
procesador.velocidad = "3,4GHz"

var grafica = Grafica()

var almacenamiento : [Almacenamiento] = [almacenamiento1, almacenamiento2]
var ram : [Ram] = [ram1, ram2]

var pc = Ordenador()
pc.precio = 500
pc.grafica = grafica
pc.procesador = procesador
pc.nombre = "Asus"
pc.almacenamiento = almacenamiento
pc.ram = ram

dump(pc)
